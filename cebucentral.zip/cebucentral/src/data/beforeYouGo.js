export const checklistItems = [
  {
    id: 'weather',
    icon: 'CloudSun',
    title: 'Check the weather',
    description:
      'Cebu conditions can shift fast. If rain chance is above 50%, bring an umbrella or rain jacket.',
    actionLabel: 'View Weather',
    actionHref: '#weather',
  },
  {
    id: 'route',
    icon: 'MapPin',
    title: 'Plan your route',
    description:
      'Know which transport you'll use and where the terminal or stop is before you leave.',
    actionLabel: 'Transport Guide',
    actionHref: '#transportation',
  },
  {
    id: 'traffic',
    icon: 'Clock',
    title: 'Factor in traffic',
    description:
      'Cebu City rush hours are 7–9 AM and 5–7 PM. Allow 30–50% extra travel time during these windows.',
    actionLabel: null,
    actionHref: null,
  },
  {
    id: 'emergency',
    icon: 'Phone',
    title: 'Save emergency numbers',
    description:
      'Save 911, the nearest hospital, and NDRRMC before you head out — especially for remote destinations.',
    actionLabel: 'Emergency Contacts',
    actionHref: '#emergency',
  },
  {
    id: 'cash',
    icon: 'Wallet',
    title: 'Bring cash (small bills)',
    description:
      'Jeepneys, buses, habal-habals, and many small stores are cash-only. Bring ₱20s and ₱50s.',
    actionLabel: null,
    actionHref: null,
  },
  {
    id: 'id',
    icon: 'CreditCard',
    title: 'Carry a valid ID',
    description:
      'Malls, government offices, ferry terminals, and airports may all require identification.',
    actionLabel: null,
    actionHref: null,
  },
  {
    id: 'offline',
    icon: 'WifiOff',
    title: 'Download offline maps',
    description:
      'Mobile signal can drop in mountain barangays and remote coastal areas. Download Google Maps offline in advance.',
    actionLabel: null,
    actionHref: null,
  },
  {
    id: 'ferry',
    icon: 'Ship',
    title: 'Ferry travel: arrive early',
    description:
      'Port check-in typically closes 30–60 minutes before departure. Factor in port access and ticket queues.',
    actionLabel: 'Ferry Info',
    actionHref: '#transportation',
  },
];
